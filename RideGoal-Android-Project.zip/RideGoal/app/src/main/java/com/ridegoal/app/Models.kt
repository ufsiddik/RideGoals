package com.ridegoal.app

data class Goal(val id:Long,val target:Double,val type:String,val days:Int,val start:String,val end:String,val originalDaily:Double,val avgFare:Double,val costType:String,val costPerRide:Double,val costPerKm:Double,val avgDistance:Double,val status:String,val completedAt:String?)
data class Ride(val id:Long,val goalId:Long,val date:String,val time:String,val fare:Double,val distance:Double?,val cost:Double,val net:Double,val note:String?)
data class Settings(val name:String="",val avgFare:Double=100.0,val costType:String="ride",val costPerRide:Double=30.0,val costPerKm:Double=3.5,val avgDistance:Double=8.0,val notifications:Boolean=true,val morning:String="08:00",val evening:String="20:00",val theme:String="system")
data class DayStats(val date:String,val target:Double,val gross:Double,val cost:Double,val net:Double,val rides:Int)
