package com.ridegoal.app
import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat
import java.util.*

object Notify {
 const val CH="ridegoal"
 fun channel(ctx:Context){if(android.os.Build.VERSION.SDK_INT>=26)(ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(CH,"RideGoal reminders",NotificationManager.IMPORTANCE_DEFAULT))}
 fun show(ctx:Context,title:String,text:String){channel(ctx);(ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify((System.currentTimeMillis()%100000).toInt(),NotificationCompat.Builder(ctx,CH).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text).setAutoCancel(true).build())}
 fun schedule(ctx:Context,hour:Int,min:Int,title:String,text:String,id:Int){val am=ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager;val i=Intent(ctx,ReminderReceiver::class.java).apply{putExtra("title",title);putExtra("text",text);putExtra("id",id)};val pi=PendingIntent.getBroadcast(ctx,id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val cal=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,hour);set(Calendar.MINUTE,min);set(Calendar.SECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1)};am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi)}
}
class ReminderReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){val db=DB(c);val g=db.goal()?:return;val sdf=java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US);val d=sdf.format(Date());val rs=db.rides(g.id,d);val actual=if(g.type=="net")rs.sumOf{it.net}else rs.sumOf{it.fare};val remaining=(g.originalDaily-actual).coerceAtLeast(0.0);val text=if(remaining<=0.0)"Daily target achieved! ${String.format(Locale.US,"₹%,.0f",actual)} earned." else "You're ${String.format(Locale.US,"₹%,.0f",remaining)} away from today's target.";Notify.show(c,"RideGoal",text)}}
