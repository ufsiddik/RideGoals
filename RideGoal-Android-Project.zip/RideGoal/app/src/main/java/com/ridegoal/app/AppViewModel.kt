package com.ridegoal.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.ceil

class AppVM(app:Application):AndroidViewModel(app){
 private val db=DB(app)
 var goal by mutableStateOf(db.goal()); private set
 var settings by mutableStateOf(db.settings()); private set
 var screen by mutableStateOf(if(goal==null)"welcome" else "home")
 var setupStep by mutableStateOf(1)
 var setupTarget by mutableStateOf(25000.0);var setupType by mutableStateOf("net");var setupDays by mutableStateOf(22);var setupStartToday by mutableStateOf(true)
 var setupCostType by mutableStateOf("ride");var setupCostRide by mutableStateOf(30.0);var setupCostKm by mutableStateOf(3.5);var setupAvgDist by mutableStateOf(8.0);var setupFare by mutableStateOf(100.0)
 var editRide by mutableStateOf<Ride?>(null)
 private val fmt=SimpleDateFormat("yyyy-MM-dd",Locale.US); private val timeFmt=SimpleDateFormat("HH:mm",Locale.US); private val pretty=SimpleDateFormat("dd MMM yyyy",Locale.US)
 init { checkPeriodEnd() }
 private fun checkPeriodEnd(){ val g=db.goal(); if(g!=null && today()>g.end){ db.updateGoal(g.copy(status="completed",completedAt=g.end)); goal=g.copy(status="completed",completedAt=g.end); screen="summary" } }
 fun today()=fmt.format(Date())
 fun datePlus(days:Int)=fmt.format(Date(System.currentTimeMillis()+days*86400000L))
 fun cost(fare:Double,distance:Double?,g:Goal):Double=if(g.costType=="ride")g.costPerRide else (distance?:g.avgDistance)*g.costPerKm
 fun allRides()=goal?.let{db.rides(it.id)}?:emptyList(); fun dayRides(d:String)=goal?.let{db.rides(it.id,d)}?:emptyList()
 fun totalApplicable():Double{val g=goal?:return 0.0;return db.rides(g.id).sumOf{if(g.type=="net")it.net else it.fare}}
 fun dayStats(d:String):DayStats{val g=goal?:return DayStats(d,0.0,0.0,0.0,0.0,0);val rs=db.rides(g.id,d);return DayStats(d,g.originalDaily,rs.sumOf{it.fare},rs.sumOf{it.cost},rs.sumOf{it.net},rs.size)}
 fun currentRequired():Double{val g=goal?:return 0.0;val rem=maxOf(0.0,g.target-totalApplicable());val end=fmt.parse(g.end)!!.time;val now=fmt.parse(today())!!.time;val remDays=maxOf(0,((end-now)/86400000L).toInt()+1);return if(remDays==0)rem else rem/remDays}
 fun daysCompleted():Int{val g=goal?:return 0;val start=fmt.parse(g.start)!!.time;val now=fmt.parse(today())!!.time;return maxOf(0,minOf(g.days,((now-start)/86400000L).toInt()+1))}
 fun createGoal(){val start=if(setupStartToday)today() else today();val end=fmt.format(Date(fmt.parse(start)!!.time+(setupDays-1)*86400000L));val daily=setupTarget/setupDays;val g=Goal(0,setupTarget,setupType,setupDays,start,end,daily,setupFare,setupCostType,setupCostRide,setupCostKm,setupAvgDist,"active",null);goal=null;db.insertGoal(g);goal=db.goal();screen="home"}
 fun addRide(fare:Double,distance:Double?,time:String,note:String?):Boolean{val g=goal?:return false;if(fare<=0)return false;val c=cost(fare,distance,g);db.insertRide(Ride(0,g.id,today(),time,fare,distance,c,fare-c,note));refresh();return true}
 fun saveRide(r:Ride):Boolean{val g=goal?:return false;if(r.fare<=0)return false;val c=cost(r.fare,r.distance,g);db.updateRide(r.copy(cost=c,net=r.fare-c));refresh();return true}
 fun removeRide(id:Long){db.deleteRide(id);refresh()}
 fun refresh(){goal=db.goal();settings=db.settings()}
 fun updateSettings(s:Settings){db.saveSettings(s);settings=s}
 fun modifyGoal(newTarget:Double,newDays:Int,newType:String,newFare:Double,newCostType:String,cpr:Double,cpk:Double,dist:Double){val g=goal?:return;val start=g.start;val end=fmt.format(Date(fmt.parse(start)!!.time+(newDays-1)*86400000L));val ng=g.copy(target=newTarget,days=newDays,type=newType,end=end,originalDaily=newTarget/newDays,avgFare=newFare,costType=newCostType,costPerRide=cpr,costPerKm=cpk,avgDistance=dist);db.updateGoal(ng);db.rides(g.id).forEach{r->val c=cost(r.fare,r.distance,ng);db.updateRide(r.copy(cost=c,net=r.fare-c))};refresh()}
 fun completeGoal(){val g=goal?:return;db.updateGoal(g.copy(status="completed",completedAt=today()));refresh();screen="history"}
 fun forecastRides():Int{val g=goal?:return 0;val per=if(g.type=="gross")g.avgFare:g.avgFare-cost(0.0,null,g);return if(per<=0)0 else ceil(g.originalDaily/per).toInt()}
 fun insight():String{val g=goal?:return "";val ds=dayStats(today());val diff=ds.target-(if(g.type=="net")ds.net else ds.gross);return when{diff>0.5->{val avg=if(g.type=="net")ds.net/ds.rides.coerceAtLeast(1) else ds.gross/ds.rides.coerceAtLeast(1);if(avg>0)"You are ₹${money(diff)} away from today's target.\nYou need approximately ${ceil(diff/avg).toInt()} more rides at your current average." else "You are ₹${money(diff)} away from today's target."};else->"Daily target achieved. You are ₹${money(-diff)} ahead of today's target."}}
 fun money(x:Double)=String.format(Locale.US,"%,.0f",x)
 fun goalProgress()=(if(goal?.target?:0.0>0) totalApplicable()/(goal!!.target)*100 else 0.0).coerceAtLeast(0.0)
 fun estimatedDailyCost():Double{val g=goal?:return 0.0;return forecastRides()*cost(0.0,null,g)}
 fun plannedGross():Double=forecastRides()*(goal?.avgFare?:0.0)
 fun plannedNet():Double=plannedGross()-estimatedDailyCost()
 fun formatDate(s:String)=try{pretty.format(fmt.parse(s)!!)}catch(_:Exception){s}
}
